﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlcDriver
{
    class SiemensPlcDriver
    {
        public static libnodave.daveOSserialType fds;       //declaration connection type
        public static libnodave.daveInterface di;           //declaration of connection interface
        public static libnodave.daveConnection dc;          //declaration of connection 

        public static int res;                              //declaration of res value for function return
        public static byte plcValue;                        //declaration of plcVaue to Read from PLC it's a byte in this case
        public static int memoryRes;                        //declaration of memoryRes for ReadBytes function return
        public static byte[] memoryBuffer = new byte[100];   //declaration of a byte array with 10 byte values
        public static int memoryResWrite;                   // WriteBytes function return
        public static byte[] memoryBufferWrite = new byte[100]; //Array for WriteBytes

        public static string eventLog = " ";                      //event string for errors
        public static bool eventTrigger = false;
        public static int eventID = 0;

        //Let's code the connect function

        public static void connectTo(string IPAddress)
        {

            //fds.rfd = libnodave.openSocket(102, "192.168.56.128");    //connect to PLC with IP Address
            fds.rfd = libnodave.openSocket(102, IPAddress);    //connect to PLC with IP Address
            fds.wfd = fds.rfd;
            if (fds.rfd > 0)
            {
                di = new libnodave.daveInterface(fds, "IF1", 0, libnodave.daveProtoISOTCP, libnodave.daveSpeed187k);
                di.setTimeout(1000000);
                res = di.initAdapter();
                dc = new libnodave.daveConnection(di, 0, 0, 2);
                res = dc.connectPLC();

                eventTrigger = true;
                eventLog = "connectTo() 0001: Connected To Siemens PLC";
                eventID = 1;
            }
            else if (fds.rfd <= 0)
            {
                eventTrigger = true;
                eventLog = "connectTo() 0002: Could not open TCP connection to " + IPAddress;
                eventID = 2;
            }

        }

        public static void disconnectTo(string IPAddress)
        {
            dc.disconnectPLC(); //disconnect PLC
            di.disconnectAdapter(); //disconnect Adapter
            libnodave.closePort(fds.rfd);   //close connection

            eventTrigger = true;
            eventLog = "disconnectTo() 0003: Disconnected from Siemens PLC";
            eventID = 3;
        }

        public static void ReadWriteTest()
        {
            memoryRes = dc.readBytes(libnodave.daveFlags, 0, 0, 1, memoryBuffer); //read a buffer of 1 byte and put it on memoryBuffer variable
            plcValue = memoryBuffer[0];   //put memoryBuffer byte value on plcValue variable

            memoryBufferWrite[0] = plcValue;
            memoryResWrite = dc.writeBytes(libnodave.daveFlags, 0, 1, 1, memoryBufferWrite);
        }

    }

}