﻿namespace Conveyor_Simulation_Version_1_0_0
{
    class Body
    {
        //Constant Variables
       
        enum Position
        {
            Left, Right, Up, Down
        }

        //Local Variables
        private int _x, _y;
        private Position _ObjPosition = Position.Right;

        //Global Variables
        public bool BodyStart, BodyStop, RecyclePos;
        public int intBodyID, TrackLength_Width, TrackLength_Height, ConvInc, Gapping, CurrentBodyPos_x, CurrentBodyPos_y, LastBodyPos_x, LastBodyPos_y;

        //Class Declaration
        EventLogger globalEventLogger = new EventLogger();

        //Constructor Initialization
        public Body(int StartBodyPos_x, int StartBodyPos_y)
        {
            this._x = StartBodyPos_x;
            this._y = StartBodyPos_y;
        }

        public int ObjectPosition_x (int x, int StartBodyPos_x)
        {
            LastBodyPos_x = CurrentBodyPos_x;

            if (_x >= TrackLength_Width && (RecyclePos || BodyStop))
            {
                _x = StartBodyPos_x;
                BodyStart = false;
            }
            else if (_x < TrackLength_Width && BodyStart)
            {
                    if (_ObjPosition == Position.Right)
                    {
                        _x += ConvInc;
                    }
                    else if (_ObjPosition == Position.Left)
                    {
                       _x -= ConvInc;
                    }
            }

            CurrentBodyPos_x = _x;
            return _x;
        }

        public int ObjectPosition_y (int y, int StartBodyPos_y)
        {
            LastBodyPos_y = CurrentBodyPos_y;

            if (_y >= TrackLength_Height && (RecyclePos || BodyStop))
            {
                _y = StartBodyPos_y;
                BodyStart = false;
            }
            else if (_y < TrackLength_Height && BodyStart)
            {
                if (_ObjPosition == Position.Up)
                {
                    _y -= ConvInc;
                }
                else if (_ObjPosition == Position.Down)
                {
                    _y += ConvInc;
                }
            }

            CurrentBodyPos_y = _y;
            return _y;
        }
    }
}
