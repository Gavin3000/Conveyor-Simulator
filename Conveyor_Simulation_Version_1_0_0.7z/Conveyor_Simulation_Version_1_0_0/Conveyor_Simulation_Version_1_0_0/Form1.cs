﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using PlcDriver;

namespace Conveyor_Simulation_Version_1_0_0
{
    public partial class Form1 : Form
    {
        //Const Declaration
        const int n = 10;
        public const int global_startPos_x = -80, global_startPos_y = 10, global_convInc = 10, global_gapping = 100, global_pageWidth = 100;

        //Build Folder and Path locations
        string folder = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Conveyor_Config.ini");

        //Variable Declaration
        private int[] _x, _y, _gapping;
        private int trkDataChkDist, trkZonStartDist, trkUnloadDist, trkDistance, trkSpeed;
        string strFileLine;
        public string IP;

        //Class Declaration
        StreamReader myFileStream;
        Dictionary<string, string> labels = new Dictionary<string, string>();
        EventLogger globalEventLogger = new EventLogger();
        Body[] BodyArray = new Body[n];
        TrackingManager TrkMgr = new TrackingManager(global_startPos_x, global_startPos_y);
        TrackingConfiguration TrkCnfg = new TrackingConfiguration();

        String[] arrAddressString;

        public Form1()
        {
            //Reference Form for Global Access of components
            Globals.form = this;

            //Form Initialization
            InitializeComponent();

            //Set Range for Unload Data Configuration
            numTrkDataCheckDistance.Maximum = tabPageTracking.Width;
            numTrkZoneStartDistance.Maximum = tabPageTracking.Width;
            numTrkUnloadDistance.Maximum = tabPageTracking.Width;
            //Read Tracking/Stop and Go Configuration .DAT files
            if (!File.Exists("DAT0001.dat"))
            {
                using (Stream output = File.Create("DAT0001.dat"))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(output, TrkCnfg);
                }
  
            }
            else
            {
                readDATfiles();
            }
            

            labelTrkUnloadRange.Text = String.Format("Unload Range: 0 - {0}", tabPageTracking.Width);

            //Tracking Configuration Initialisation
            TrkCnfg.scalingFactor(tabPageTracking.Width);

            //Initialise BodyData Array
            _x = new int[n];
            _y = new int[n];
            _gapping = new int[n];

            //Body Initialisation
            for (int i = 0; i < n; i++)
            {
                _x[i] = global_startPos_x;
                _y[i] = global_startPos_y;
                _gapping[i] = global_gapping;

                BodyArray[i] = new Body(_x[i],_y[i])
                {
                    BodyStart = false,
                    BodyStop = false,
                    RecyclePos = false,
                    intBodyID = i,
                    TrackLength_Width = tabPageTracking.Width,
                    TrackLength_Height = tabPageTracking.Height,
                    ConvInc = Convert.ToInt32(TrkCnfg.dScalingFactor),
                    //ConvInc = global_convInc,
                    Gapping = _gapping[i]
                };
                
            }
            //Tracking Initialisation
            TrkMgr = new TrackingManager(global_startPos_x, global_startPos_y)
            {
                BodyQueueSize = n,
                BodyData = BodyArray
            };

            //On Initialization of the Form read the IPAddress from the Proxy File            
            //Initialize Startup
            globalEventLogger.eventLogList("0001","Form1.cs Form1()","Initializing: Startup");    //Event Log :Initialize: Startup
            globalEventLogger.eventLogList("0002", "Form1.cs Form1()", "Initializing: Version: 1.0.0");    //Event Log :Initialize: Version

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            //If File does not exist
            if (!File.Exists(path))
            {
                try
                {
                    //Create a file to write to
                    string[] createText = { "//Please Add IP Address Below", "//E.g. 192.168.0.1", folder, "192.168.0.1" };
                    File.WriteAllLines(path, createText);
                    textBoxIpAddLoc.Text = folder;
                    globalEventLogger.eventLogList("0003", "Form1.cs Form1()", "Initializing: Missing Conveyor_Config.ini file"); //Event Log :Initialize: Check for Text File
                    globalEventLogger.eventLogList("0004", "Form1.cs Form1()", "Initializing: Created : " + path); //Event Log :Initialize: Build Proxy.txt
                    globalEventLogger.eventLogList("0005", "Form1.cs Form1()", "Initializing: Created Default IP Address : " + createText[3]); //Event Log :Initialize: Import Default IP
                }
                catch (Exception exp)
                {
                    MessageBox.Show("An error occurred while attempting to load the file. The error is:"
                                    + System.Environment.NewLine + exp.ToString() + System.Environment.NewLine);
                }
            }
            Invalidate();

            textBoxIpAddLoc.Text = folder;

            //instead of having to close the stream i.e.myFileStream.close(), 'using' takes care of this
            using (myFileStream = new StreamReader(path))
            {
                // Skip first 3 lines of the text file?
                foreach (var i in Enumerable.Range(1, 3)) myFileStream.ReadLine();

                //Used to Split the IPAddress in Array Components
                // i.e "192.168.0.1" will be split in [0] = 192, [1] = 168, etc...
                while ((strFileLine = myFileStream.ReadLine()) != null)
                {
                    arrAddressString = strFileLine.Split('.');
                    labelIPAddress.Text = strFileLine.ToString();
                    IP = strFileLine.ToString();

                    for (int i = 0; i < arrAddressString.Length; i++)
                    {
                        globalEventLogger.eventLogList("0006", "Form1.cs Form1()", "Initializing: " + String.Format("IP Address Build {0}: ", i) + arrAddressString[i]); //Event Log :IP Address Build                   
                        labels.Add(String.Format("xlabel{0}", i + 1), arrAddressString[i]);   //Using the Dictionary feature, added values from array in to variables for use in Textbox
                    }

                }

                //Populate Edit IP Address Text Box with Default IP
                ipAddressBox1.Text = labels["xlabel1"];
                ipAddressBox2.Text = labels["xlabel2"];
                ipAddressBox3.Text = labels["xlabel3"];
                ipAddressBox4.Text = labels["xlabel4"];
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Properties.Settings.Default.IPAddress = "192.168.100.10";
            Properties.Settings.Default.Save();
        }

        private void buttonNetworkConnect_Click(object sender, EventArgs e)
        {
            SiemensPlcDriver.connectTo(IP);
            if (SiemensPlcDriver.fds.rfd > 0)
            {
                timerNetworkScan.Enabled = true;
            }

            if (SiemensPlcDriver.eventID == 1)
            {
                buttonNetworkConnect.Enabled = false;
                buttonNetworkDisconnect.Enabled = true;
                groupBoxIpAdd.Enabled = false;
                groupBoxIpAddPath.Enabled = false;
            }
            else if (SiemensPlcDriver.eventID != 1)
            {
                buttonNetworkConnect.Enabled = true;
                buttonNetworkDisconnect.Enabled = false;
                groupBoxIpAdd.Enabled = true;
                groupBoxIpAddPath.Enabled = true;
            }

        }

        private void timerNetworkScan_Tick(object sender, EventArgs e)
        {
            SiemensPlcDriver.ReadWriteTest();
            labelNetworkTestValue.Text = SiemensPlcDriver.plcValue.ToString();
        }

        private void buttonNetworkDisconnect_Click(object sender, EventArgs e)
        {
            SiemensPlcDriver.disconnectTo(IP);
            timerNetworkScan.Enabled = false;
           
            if (SiemensPlcDriver.eventID == 3)
            {
                buttonNetworkConnect.Enabled = true;
                buttonNetworkDisconnect.Enabled = false;
                groupBoxIpAdd.Enabled = true;
                groupBoxIpAddPath.Enabled = true;
            }
            else if (SiemensPlcDriver.eventID != 3)
            {
                buttonNetworkConnect.Enabled = false;
                buttonNetworkDisconnect.Enabled = true;
                groupBoxIpAdd.Enabled = false;
                groupBoxIpAddPath.Enabled = false;
            }
        }

        private void timerEventLog_Tick(object sender, EventArgs e)
        {
            if (SiemensPlcDriver.eventTrigger == true)
            {
                globalEventLogger.eventLogList("0100", "SiemensPlcDriver.cs", SiemensPlcDriver.eventLog.ToString());
                
                SiemensPlcDriver.eventTrigger = false;
                SiemensPlcDriver.eventID = 0;
            }

        }

        private void buttonIpAddSave_Click(object sender, EventArgs e)
        {

                //If File does not exist
                if (!File.Exists(path))
                {
                    //Create a file to write to
                    string[] createText = { "//Please Add IP Address Below", "//E.g. 192.168.0.1", folder, ipAddressBox1.Text + "." + ipAddressBox2.Text + "." + ipAddressBox3.Text + "." + ipAddressBox4.Text };
                    File.WriteAllLines(path, createText);
                    globalEventLogger.eventLogList("0007", "Form1.cs buttonIpAddSave_Click()", "Saving: Missing Conveyor_Config.ini file"); //Event Log :Saving: Check for Text File
                    globalEventLogger.eventLogList("0008", "Form1.cs buttonIpAddSave_Click()", "Saving: Created : " + path); //Event Log :Saving: Build Proxy.txt
                    globalEventLogger.eventLogList("0009", "Form1.cs buttonIpAddSave_Click()", "Saving: Created new IP Address : " + createText[3]); //Event Log :Saving: Import Default IP
                }
                else
                {
                    //Create a file to write to
                    string[] createText = { "//Please Add IP Address Below", "//E.g. 192.168.0.1", folder, ipAddressBox1.Text + "." + ipAddressBox2.Text + "." + ipAddressBox3.Text + "." + ipAddressBox4.Text };
                    File.WriteAllLines(path, createText);
                    globalEventLogger.eventLogList("0010", "Form1.cs buttonIpAddSave_Click()", "Saving: Created new IP Address : " + createText[3]); //Event Log :Saving: Import Default IP
                }

                //instead of having to close the stream, 'using' takes care of this
                using (myFileStream = new StreamReader(path))
                {
                    // Skip first 3 lines of the text file?
                    foreach (var i in Enumerable.Range(1, 3)) myFileStream.ReadLine();

                    //Used to Split the IPAddress in Array Components
                    // i.e "192.168.0.1" will be split in [0] = 192, [1] = 168, etc...
                    while ((strFileLine = myFileStream.ReadLine()) != null)
                    {
                        arrAddressString = strFileLine.Split('.');
                        labelIPAddress.Text = strFileLine.ToString();
                        IP = strFileLine.ToString();
                    }
                }

        }

        private void openFileDialogIpAdd_FileOk(object sender, CancelEventArgs e)
        {
            globalEventLogger.eventLogList("0011", "Form1.cs openFileDialogIpAdd_FileOk()", "Locating: FileDirectory valid"); //Event Log :Locating: File Validitiy
        }

        private void buttonTrkSave_Click(object sender, EventArgs e)
        {
            //Convert from Decimal to Int for internal use
            trkDataChkDist = Convert.ToInt32(numTrkDataCheckDistance.Value);
            trkZonStartDist = Convert.ToInt32(numTrkZoneStartDistance.Value);
            trkUnloadDist = Convert.ToInt32(numTrkUnloadDistance.Value);
            trkDistance = Convert.ToInt32(numTrkDistance.Value);
            trkSpeed = Convert.ToInt32(numTrkSpeed.Value);

            //Update values for Serialization
            TrkCnfg.DataSave(trkDataChkDist, trkZonStartDist, trkUnloadDist, trkDistance, trkSpeed);
            TrkCnfg.scalingFactor(tabPageTracking.Width);

            //Write to DAT0001.dat file with new values
            using (Stream output = File.OpenWrite("DAT0001.dat"))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(output, TrkCnfg);
            }

            //Update Tracking Tab
            tabPageTracking.Invalidate();
            tabPageTracking.Refresh();
        }

        private void buttonOpenPathLoc_Click(object sender, EventArgs e)
        {
            // Show the FolderBrowserDialog.
            DialogResult result = folderBrowserDialogIpAdd.ShowDialog();
            if (result == DialogResult.OK)
            {
                textBoxIpAddLoc.Text = folderBrowserDialogIpAdd.SelectedPath;

            }
        }

        //Build reference to ListBox for EventLogger
        public void addEventLogger(string item)
        {
            listBoxLog.Items.Add(item);
        }

        //Deserialize .DAT files for last configuration inputs saved
        private void readDATfiles()
        {
            //DAT0001.dat generated from Class TrackingConfiguration
            using (Stream input = File.OpenRead("DAT0001.dat"))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                //Check the Stream is not empty then deserialize from it
                if (!(input.Length == 0))
                {
                    TrkCnfg = (TrackingConfiguration)formatter.Deserialize(input);
                }
            }
            numTrkDataCheckDistance.Value = TrkCnfg.SavedDataCheck;
            numTrkZoneStartDistance.Value = TrkCnfg.SavedZoneStart;
            numTrkUnloadDistance.Value = TrkCnfg.SavedUnload;
            numTrkDistance.Value = TrkCnfg.SavedDistance;
            numTrkSpeed.Value = TrkCnfg.SavedSpeed;

            trkDataChkDist = TrkCnfg.SavedDataCheck;
            trkZonStartDist = TrkCnfg.SavedZoneStart;
            trkUnloadDist = TrkCnfg.SavedUnload;
            trkDistance = TrkCnfg.SavedDistance;
            trkSpeed = TrkCnfg.SavedSpeed;
        }

        //Build Tracking Animation
        private void tabPageTracking_Paint(object sender, PaintEventArgs e)
        {
            
            //Track
            e.Graphics.FillRectangle(Brushes.Gray, 0, 10, tabPageTracking.Width, 50);
            //Datacheck
            e.Graphics.DrawImage(new Bitmap(@"Images\Sensors\Sensor_Up.png"), trkDataChkDist, 65, 20, 45);
            e.Graphics.DrawString("DC", new Font("Arial", 8), new SolidBrush(Color.Black), trkDataChkDist, 115);
            //Zonestart
            e.Graphics.DrawImage(new Bitmap(@"Images\Sensors\Sensor_Up.png"), trkZonStartDist, 65, 20, 45);
            e.Graphics.DrawString("ZS", new Font("Arial", 8), new SolidBrush(Color.Black), trkZonStartDist, 115);
            //Unload
            e.Graphics.DrawLine(new Pen(Color.Black, 3), trkUnloadDist, 10, trkUnloadDist, 60);
            //Need to define the string in pixels to format location to position it
            var unloadString = "Unload";
            SizeF unloadStringSize = e.Graphics.MeasureString(unloadString, new Font("Ariel", 8));
            int unloadStringSizeInt = Convert.ToInt32(unloadStringSize.Width/2);
            e.Graphics.DrawString(unloadString, new Font("Arial", 8), new SolidBrush(Color.Black), trkUnloadDist-unloadStringSizeInt, 65);
            //Bodies
            for (int i = 0; i < n; i++)
            {
                e.Graphics.DrawImage(new Bitmap(@"Images\Vehicles\car.png"), _x[i], _y[i], 80, 50);
                e.Graphics.DrawString(string.Format("{0}",i), 
                                      new Font("Arial", 8), 
                                      new SolidBrush(Color.White),
                                      _x[i]+60,_y[i]+17);
            }
            
        }
   
        private void timerMoving_Tick(object sender, EventArgs e)
        {
            //Update Position of Bodies
            for (int i = 0; i < n; i++)
            {
                _x[i] = BodyArray[i].ObjectPosition_x(_x[i], global_startPos_x);
                BodyArray[i].ConvInc = Convert.ToInt32(TrkCnfg.dScalingFactor);
                //When this is called, always set to 0, as we are not incrementing the y axis
                //_y[i] = BodyArray[i].ObjectPosition_y(_y[i]);
            }
            //Check All Bodies have stopped
            var bodyQueueFinished = BodyArray.All(body => body.BodyStop == true);
            if (bodyQueueFinished)
            {
                buttonTrkStop.PerformClick();
            }
            //Testing Line Manager
            TrkMgr.LineManager();
            //Update and Refresh Tab Control
            tabPageTracking.Invalidate();
            tabPageTracking.Refresh();

        }

        private void buttonTrkStart_Click(object sender, EventArgs e)
        {
            var bodyQueueActive = BodyArray.Any(body => body.CurrentBodyPos_x > 0);
            if (!bodyQueueActive)
            {
                BodyArray[0].BodyStart = true;
                for (int i = 0; i < n; i++)
                {
                    BodyArray[i].BodyStop = false;
                }
            }
            else
            {
                for (int i = 0; i < n; i++)
                {
                    if (BodyArray[i].CurrentBodyPos_x > global_startPos_x)
                    {
                        BodyArray[i].BodyStart = true;
                        BodyArray[i].BodyStop = false;
                    }
                }
            }

            timerMoving.Enabled = true;
            buttonTrkStart.Enabled = false;
            buttonTrkStop.Enabled = true;
            groupBoxSensorConfig.Enabled = false;
            groupBoxTrkConfig.Enabled = false;
        }

        private void buttonTrkStop_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < n; i++)
            {
                BodyArray[i].BodyStart = false;
                BodyArray[i].BodyStop = true;
            }
            timerMoving.Enabled = false;
            buttonTrkStart.Enabled = true;
            buttonTrkStop.Enabled = false;
            groupBoxSensorConfig.Enabled = true;
            //Check if any Body has an Active position
            var bodyQueueActive = BodyArray.Any(body => body.CurrentBodyPos_x > global_startPos_x);
            if (!bodyQueueActive)
            {
                groupBoxTrkConfig.Enabled = true;
            }
            else
            {
                groupBoxTrkConfig.Enabled = false;
            }

        }

        private void checkBoxCycle_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxCycle.Checked)
            {
                for (int i = 0; i < n; i++)
                {
                    BodyArray[i].RecyclePos = true;
                }
            }
            else
            {
                for (int i = 0; i < n; i++)
                {
                    BodyArray[i].RecyclePos = false;
                }
            }
        }
    }
}
