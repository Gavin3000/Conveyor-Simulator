﻿using System;

namespace Conveyor_Simulation_Version_1_0_0
{
    [Serializable]
    class TrackingConfiguration
    {
        //global variables
        public int SavedDataCheck, SavedZoneStart, SavedUnload, SavedDistance, SavedSpeed;
        public decimal dScalingFactor;

        public void DataSave(int DataCheck, int ZoneStart, int Unload, int Distance, int Speed)
        {
            SavedDataCheck = DataCheck;
            SavedZoneStart = ZoneStart;
            SavedUnload = Unload;
            SavedDistance = Distance;
            SavedSpeed = Speed;

        }

        public decimal scalingFactor(int PageWidth)
        {
            int speed, distance, timeinterval = 60, decfactor_m = 100;
            decimal tmp1, tmp2, tmp3;

            speed = SavedSpeed;
            distance = SavedDistance;

            tmp1 = (speed*decfactor_m) / timeinterval;
            tmp2 = (distance*decfactor_m) / PageWidth;

            tmp3 = tmp1 / tmp2;

            dScalingFactor = tmp3;

            return dScalingFactor;
        }
    }
}
