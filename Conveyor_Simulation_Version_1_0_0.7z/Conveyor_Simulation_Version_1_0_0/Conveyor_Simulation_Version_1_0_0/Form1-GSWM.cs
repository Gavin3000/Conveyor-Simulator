﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using PlcDriver;

namespace Conveyor_Simulation_Version_1_0_0
{
    public partial class Form1 : Form
    {
        /* Setup for Object Movement Test for Tracking Page*/
        enum Position
        {
            Left, Right, Up, Down
        }
        /*-------------------------------------------------*/
        StreamReader myFileStream;

        Dictionary<string, string> labels = new Dictionary<string, string>();

        EventLogger globalEventLogger = new EventLogger();

        public string IP;

        string strFileLine;
        string folder = @"c:\Temp";
        string path = @"c:\Temp\proxy.txt";

        String[] arrAddressString;

        /* Setup for Tracking Movement Test */
        //Car Object Movement
        private int _x;
        private int _y;
        private Position _ObjPosition;
        /*----------------------------------*/
        public Form1()
        {
            //Reference Form for Global Access of components
            Globals.form = this;
            //Form Initialization
            InitializeComponent();

            //On Initialization of the Form read the IPAddress from the Proxy File            
            //Initialize Startup
            globalEventLogger.eventLogList("0001","Form1.cs Form1()","Initializing: Startup");    //Event Log :Initialize: Startup
            globalEventLogger.eventLogList("0002", "Form1.cs Form1()", "Initializing: Version: 1.0.0");    //Event Log :Initialize: Version

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            //If File does not exist
            if (!File.Exists(path))
            {
                try
                {
                    //Create a file to write to
                    string[] createText = { "//Please Add IP Address Below", "//E.g. 192.168.0.1", folder, "192.168.0.1" };
                    File.WriteAllLines(path, createText);
                    textBoxIpAddLoc.Text = folder;
                    globalEventLogger.eventLogList("0003", "Form1.cs Form1()", "Initializing: Missing Proxy.txt file"); //Event Log :Initialize: Check for Text File
                    globalEventLogger.eventLogList("0004", "Form1.cs Form1()", "Initializing: Created : " + path); //Event Log :Initialize: Build Proxy.txt
                    globalEventLogger.eventLogList("0005", "Form1.cs Form1()", "Initializing: Created Default IP Address : " + createText[3]); //Event Log :Initialize: Import Default IP
                }
                catch (Exception exp)
                {
                    MessageBox.Show("An error occurred while attempting to load the file. The error is:"
                                    + System.Environment.NewLine + exp.ToString() + System.Environment.NewLine);
                }
            }
            Invalidate();

            textBoxIpAddLoc.Text = folder;

            myFileStream = new StreamReader(path);

            // Skip first 3 lines of the text file?
            foreach (var i in Enumerable.Range(1, 3)) myFileStream.ReadLine();
        
            //Used to Split the IPAddress in Array Components
            // i.e "192.168.0.1" will be split in [0] = 192, [1] = 168, etc...
            while ((strFileLine = myFileStream.ReadLine()) != null)
            {
                arrAddressString = strFileLine.Split('.');
                labelIPAddress.Text = strFileLine.ToString();
                IP = strFileLine.ToString();

                for (int i = 0; i < arrAddressString.Length; i++)
                {
                    globalEventLogger.eventLogList("0006", "Form1.cs Form1()", "Initializing: " + String.Format("IP Address Build {0}: ", i) + arrAddressString[i]); //Event Log :IP Address Build                   
                    labels.Add(String.Format("xlabel{0}", i+1), arrAddressString[i]);   //Using the Dictionary feature, added values from array in to variables for use in Textbox
                }

            }

            //Populate Edit IP Address Text Box with Default IP
            ipAddressBox1.Text = labels["xlabel1"];
            ipAddressBox2.Text = labels["xlabel2"];
            ipAddressBox3.Text = labels["xlabel3"];
            ipAddressBox4.Text = labels["xlabel4"];

            myFileStream.Close();

            /* Setup for Tracking Movement Test*/
            //Test Move object - Initialize Position
            _x = 50;
            _y = 50;
            _ObjPosition = Position.Right;
            /*---------------------------------*/

        }

        private void buttonNetworkConnect_Click(object sender, EventArgs e)
        {
            SiemensPlcDriver.connectTo(IP);
            if (SiemensPlcDriver.fds.rfd > 0)
            {
                timerNetworkScan.Enabled = true;
            }

            if (SiemensPlcDriver.eventID == 1)
            {
                buttonNetworkConnect.Enabled = false;
                buttonNetworkDisconnect.Enabled = true;
                groupBoxIpAdd.Enabled = false;
                groupBoxIpAddPath.Enabled = false;
            }
            else if (SiemensPlcDriver.eventID != 1)
            {
                buttonNetworkConnect.Enabled = true;
                buttonNetworkDisconnect.Enabled = false;
                groupBoxIpAdd.Enabled = true;
                groupBoxIpAddPath.Enabled = true;
            }

        }

        private void timerNetworkScan_Tick(object sender, EventArgs e)
        {
            SiemensPlcDriver.ReadWriteTest();
            labelNetworkTestValue.Text = SiemensPlcDriver.plcValue.ToString();
        }

        private void buttonNetworkDisconnect_Click(object sender, EventArgs e)
        {
            SiemensPlcDriver.disconnectTo(IP);
            timerNetworkScan.Enabled = false;
           
            if (SiemensPlcDriver.eventID == 3)
            {
                buttonNetworkConnect.Enabled = true;
                buttonNetworkDisconnect.Enabled = false;
                groupBoxIpAdd.Enabled = true;
                groupBoxIpAddPath.Enabled = true;
            }
            else if (SiemensPlcDriver.eventID != 3)
            {
                buttonNetworkConnect.Enabled = false;
                buttonNetworkDisconnect.Enabled = true;
                groupBoxIpAdd.Enabled = false;
                groupBoxIpAddPath.Enabled = false;
            }
        }

        private void timerEventLog_Tick(object sender, EventArgs e)
        {
            if (SiemensPlcDriver.eventTrigger == true)
            {
                globalEventLogger.eventLogList("0100", "SiemensPlcDriver.cs", SiemensPlcDriver.eventLog.ToString());
                
                SiemensPlcDriver.eventTrigger = false;
                SiemensPlcDriver.eventID = 0;
            }

        }

        private void buttonIpAddSave_Click(object sender, EventArgs e)
        {

                //If File does not exist
                if (!File.Exists(path))
                {
                    //Create a file to write to
                    string[] createText = { "//Please Add IP Address Below", "//E.g. 192.168.0.1", folder, ipAddressBox1.Text + "." + ipAddressBox2.Text + "." + ipAddressBox3.Text + "." + ipAddressBox4.Text };
                    File.WriteAllLines(path, createText);
                    globalEventLogger.eventLogList("0007", "Form1.cs buttonIpAddSave_Click()", "Saving: Missing Proxy.txt file"); //Event Log :Saving: Check for Text File
                    globalEventLogger.eventLogList("0008", "Form1.cs buttonIpAddSave_Click()", "Saving: Created : " + path); //Event Log :Saving: Build Proxy.txt
                    globalEventLogger.eventLogList("0009", "Form1.cs buttonIpAddSave_Click()", "Saving: Created new IP Address : " + createText[3]); //Event Log :Saving: Import Default IP
                }
                else
                {
                    //Create a file to write to
                    string[] createText = { "//Please Add IP Address Below", "//E.g. 192.168.0.1", folder, ipAddressBox1.Text + "." + ipAddressBox2.Text + "." + ipAddressBox3.Text + "." + ipAddressBox4.Text };
                    File.WriteAllLines(path, createText);
                    globalEventLogger.eventLogList("0010", "Form1.cs buttonIpAddSave_Click()", "Saving: Created new IP Address : " + createText[3]); //Event Log :Saving: Import Default IP
                }
                myFileStream = new StreamReader(path);

                // Skip first 3 lines of the text file?
                foreach (var i in Enumerable.Range(1, 3)) myFileStream.ReadLine();

                //Used to Split the IPAddress in Array Components
                // i.e "192.168.0.1" will be split in [0] = 192, [1] = 168, etc...
                while ((strFileLine = myFileStream.ReadLine()) != null)
                {
                    arrAddressString = strFileLine.Split('.');
                    labelIPAddress.Text = strFileLine.ToString();
                    IP = strFileLine.ToString();
                }

                myFileStream.Close();
        }

        private void openFileDialogIpAdd_FileOk(object sender, CancelEventArgs e)
        {
            globalEventLogger.eventLogList("0011", "Form1.cs openFileDialogIpAdd_FileOk()", "Locating: FileDirectory valid"); //Event Log :Locating: File Validitiy
        }

        private void buttonOpenPathLoc_Click(object sender, EventArgs e)
        {
            // Show the FolderBrowserDialog.
            DialogResult result = folderBrowserDialogIpAdd.ShowDialog();
            if (result == DialogResult.OK)
            {
                textBoxIpAddLoc.Text = folderBrowserDialogIpAdd.SelectedPath;

            }
        }

        //Build reference to ListBox for EventLogger
        public void addEventLogger(string item)
        {
            listBoxLog.Items.Add(item);
        }
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
// Testing Movement of Objects -- Still not refereshing in real time, This is probably to do with the Tab Control it is nested in:.

/*            Check Out discussion on stackoverflow.com/questions/15209870/dynamically-updating-tabcontrol-at-runtime, it might help.
 *            Look at your C# Book as well, how was the animation created for the WPF project?
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
        private void tabPageTracking_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.FillRectangle(Brushes.BlueViolet, _x, _y, 100, 100);
            e.Graphics.DrawImage(new Bitmap("car.png"), _x, _y, 80, 50);
        }

        private void timerMoving_Tick(object sender, EventArgs e)
        {
            if (_ObjPosition == Position.Right)
            {
                _x += 10;
            }
            else if (_ObjPosition == Position.Left)
            {
                _x -= 10;
            }
            else if (_ObjPosition == Position.Up)
            {
                _y -= 10;
            }
            else if (_ObjPosition == Position.Down)
            {
                _y += 10;
            }
            //Used to update location for the TabControl tabPageTracking
            tabPageTracking.Invalidate();
            tabPageTracking.Refresh();
        }

        private void buttonTrkStart_Click(object sender, EventArgs e)
        {
            timerMoving.Enabled = true;
        }

        private void buttonTrkStop_Click(object sender, EventArgs e)
        {
            timerMoving.Enabled = false;
            _x = 50;
        }

        /*--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    }
}
