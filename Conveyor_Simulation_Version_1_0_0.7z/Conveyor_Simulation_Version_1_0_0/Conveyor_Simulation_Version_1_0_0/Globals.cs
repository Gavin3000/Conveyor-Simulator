﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conveyor_Simulation_Version_1_0_0
{
    class Globals
    {
        public static Form1 form;
    }
}
