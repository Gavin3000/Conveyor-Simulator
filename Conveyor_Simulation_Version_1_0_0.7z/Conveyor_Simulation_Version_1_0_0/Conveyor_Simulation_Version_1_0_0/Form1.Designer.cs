﻿namespace Conveyor_Simulation_Version_1_0_0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControlConveyorSim = new System.Windows.Forms.TabControl();
            this.tabPageTracking = new System.Windows.Forms.TabPage();
            this.groupBoxTrkConfig = new System.Windows.Forms.GroupBox();
            this.numTrkSpeed = new System.Windows.Forms.NumericUpDown();
            this.numTrkDistance = new System.Windows.Forms.NumericUpDown();
            this.labelTrackSpeed = new System.Windows.Forms.Label();
            this.labelTrkDistance = new System.Windows.Forms.Label();
            this.groupBoxSensorConfig = new System.Windows.Forms.GroupBox();
            this.buttonTrkSave = new System.Windows.Forms.Button();
            this.labelTrkUnloadRange = new System.Windows.Forms.Label();
            this.numTrkUnloadDistance = new System.Windows.Forms.NumericUpDown();
            this.numTrkZoneStartDistance = new System.Windows.Forms.NumericUpDown();
            this.numTrkDataCheckDistance = new System.Windows.Forms.NumericUpDown();
            this.labelUnloadDistance = new System.Windows.Forms.Label();
            this.labelZoneStartDistance = new System.Windows.Forms.Label();
            this.labelDataCheckDistance = new System.Windows.Forms.Label();
            this.checkBoxCycle = new System.Windows.Forms.CheckBox();
            this.buttonTrkStop = new System.Windows.Forms.Button();
            this.buttonTrkStart = new System.Windows.Forms.Button();
            this.tabPageStopGo = new System.Windows.Forms.TabPage();
            this.tabPageConvConfig = new System.Windows.Forms.TabPage();
            this.groupBoxConvConfigAdd = new System.Windows.Forms.GroupBox();
            this.buttonConvConfigLoc = new System.Windows.Forms.Button();
            this.textBoxConvConfigPath = new System.Windows.Forms.TextBox();
            this.groupBoxPlcDbConfig = new System.Windows.Forms.GroupBox();
            this.textBoxByteSize = new System.Windows.Forms.TextBox();
            this.textBoxDbNo = new System.Windows.Forms.TextBox();
            this.labelByteArraySize = new System.Windows.Forms.Label();
            this.labelDataBlockNo = new System.Windows.Forms.Label();
            this.tabPageNetConfig = new System.Windows.Forms.TabPage();
            this.groupBoxComms = new System.Windows.Forms.GroupBox();
            this.buttonNetworkConnect = new System.Windows.Forms.Button();
            this.buttonNetworkDisconnect = new System.Windows.Forms.Button();
            this.groupBoxIpAddPath = new System.Windows.Forms.GroupBox();
            this.buttonOpenPathLoc = new System.Windows.Forms.Button();
            this.textBoxIpAddLoc = new System.Windows.Forms.TextBox();
            this.groupBoxIpAdd = new System.Windows.Forms.GroupBox();
            this.buttonIpAddSave = new System.Windows.Forms.Button();
            this.ipAddressBox1 = new System.Windows.Forms.TextBox();
            this.ipAddressBox4 = new System.Windows.Forms.TextBox();
            this.ipAddressBox2 = new System.Windows.Forms.TextBox();
            this.ipAddressBox3 = new System.Windows.Forms.TextBox();
            this.labelTestText = new System.Windows.Forms.Label();
            this.labelNetworkTestValue = new System.Windows.Forms.Label();
            this.labelIPAddressTitle = new System.Windows.Forms.Label();
            this.labelIPAddress = new System.Windows.Forms.Label();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.tabPageLog = new System.Windows.Forms.TabPage();
            this.listBoxLog = new System.Windows.Forms.ListBox();
            this.tabPageAbout = new System.Windows.Forms.TabPage();
            this.labelAboutVersion = new System.Windows.Forms.Label();
            this.labelAboutProgramTitle = new System.Windows.Forms.Label();
            this.labelAboutTitle = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.rectangleAboutLogo = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.timerNetworkScan = new System.Windows.Forms.Timer(this.components);
            this.timerEventLog = new System.Windows.Forms.Timer(this.components);
            this.openFileDialogIpAdd = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialogIpAdd = new System.Windows.Forms.FolderBrowserDialog();
            this.timerMoving = new System.Windows.Forms.Timer(this.components);
            this.tabControlConveyorSim.SuspendLayout();
            this.tabPageTracking.SuspendLayout();
            this.groupBoxTrkConfig.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkDistance)).BeginInit();
            this.groupBoxSensorConfig.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkUnloadDistance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkZoneStartDistance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkDataCheckDistance)).BeginInit();
            this.tabPageConvConfig.SuspendLayout();
            this.groupBoxConvConfigAdd.SuspendLayout();
            this.groupBoxPlcDbConfig.SuspendLayout();
            this.tabPageNetConfig.SuspendLayout();
            this.groupBoxComms.SuspendLayout();
            this.groupBoxIpAddPath.SuspendLayout();
            this.groupBoxIpAdd.SuspendLayout();
            this.tabPageLog.SuspendLayout();
            this.tabPageAbout.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlConveyorSim
            // 
            this.tabControlConveyorSim.Controls.Add(this.tabPageTracking);
            this.tabControlConveyorSim.Controls.Add(this.tabPageStopGo);
            this.tabControlConveyorSim.Controls.Add(this.tabPageConvConfig);
            this.tabControlConveyorSim.Controls.Add(this.tabPageNetConfig);
            this.tabControlConveyorSim.Controls.Add(this.tabPageLog);
            this.tabControlConveyorSim.Controls.Add(this.tabPageAbout);
            this.tabControlConveyorSim.Location = new System.Drawing.Point(0, 0);
            this.tabControlConveyorSim.Name = "tabControlConveyorSim";
            this.tabControlConveyorSim.SelectedIndex = 0;
            this.tabControlConveyorSim.Size = new System.Drawing.Size(575, 474);
            this.tabControlConveyorSim.TabIndex = 0;
            // 
            // tabPageTracking
            // 
            this.tabPageTracking.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageTracking.Controls.Add(this.groupBoxTrkConfig);
            this.tabPageTracking.Controls.Add(this.groupBoxSensorConfig);
            this.tabPageTracking.Controls.Add(this.checkBoxCycle);
            this.tabPageTracking.Controls.Add(this.buttonTrkStop);
            this.tabPageTracking.Controls.Add(this.buttonTrkStart);
            this.tabPageTracking.Location = new System.Drawing.Point(4, 22);
            this.tabPageTracking.Name = "tabPageTracking";
            this.tabPageTracking.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTracking.Size = new System.Drawing.Size(567, 448);
            this.tabPageTracking.TabIndex = 0;
            this.tabPageTracking.Text = "Tracking";
            this.tabPageTracking.Paint += new System.Windows.Forms.PaintEventHandler(this.tabPageTracking_Paint);
            // 
            // groupBoxTrkConfig
            // 
            this.groupBoxTrkConfig.Controls.Add(this.numTrkSpeed);
            this.groupBoxTrkConfig.Controls.Add(this.numTrkDistance);
            this.groupBoxTrkConfig.Controls.Add(this.labelTrackSpeed);
            this.groupBoxTrkConfig.Controls.Add(this.labelTrkDistance);
            this.groupBoxTrkConfig.Location = new System.Drawing.Point(271, 230);
            this.groupBoxTrkConfig.Name = "groupBoxTrkConfig";
            this.groupBoxTrkConfig.Size = new System.Drawing.Size(284, 77);
            this.groupBoxTrkConfig.TabIndex = 5;
            this.groupBoxTrkConfig.TabStop = false;
            this.groupBoxTrkConfig.Text = "Track Configuration";
            // 
            // numTrkSpeed
            // 
            this.numTrkSpeed.Location = new System.Drawing.Point(161, 46);
            this.numTrkSpeed.Name = "numTrkSpeed";
            this.numTrkSpeed.Size = new System.Drawing.Size(120, 20);
            this.numTrkSpeed.TabIndex = 7;
            // 
            // numTrkDistance
            // 
            this.numTrkDistance.Location = new System.Drawing.Point(161, 20);
            this.numTrkDistance.Name = "numTrkDistance";
            this.numTrkDistance.Size = new System.Drawing.Size(120, 20);
            this.numTrkDistance.TabIndex = 6;
            // 
            // labelTrackSpeed
            // 
            this.labelTrackSpeed.AutoSize = true;
            this.labelTrackSpeed.Location = new System.Drawing.Point(33, 48);
            this.labelTrackSpeed.Name = "labelTrackSpeed";
            this.labelTrackSpeed.Size = new System.Drawing.Size(107, 13);
            this.labelTrackSpeed.TabIndex = 4;
            this.labelTrackSpeed.Text = "Track Speed (m/min)";
            // 
            // labelTrkDistance
            // 
            this.labelTrkDistance.AutoSize = true;
            this.labelTrkDistance.Location = new System.Drawing.Point(33, 22);
            this.labelTrkDistance.Name = "labelTrkDistance";
            this.labelTrkDistance.Size = new System.Drawing.Size(97, 13);
            this.labelTrkDistance.TabIndex = 3;
            this.labelTrkDistance.Text = "Track Distance (m)";
            // 
            // groupBoxSensorConfig
            // 
            this.groupBoxSensorConfig.Controls.Add(this.buttonTrkSave);
            this.groupBoxSensorConfig.Controls.Add(this.labelTrkUnloadRange);
            this.groupBoxSensorConfig.Controls.Add(this.numTrkUnloadDistance);
            this.groupBoxSensorConfig.Controls.Add(this.numTrkZoneStartDistance);
            this.groupBoxSensorConfig.Controls.Add(this.numTrkDataCheckDistance);
            this.groupBoxSensorConfig.Controls.Add(this.labelUnloadDistance);
            this.groupBoxSensorConfig.Controls.Add(this.labelZoneStartDistance);
            this.groupBoxSensorConfig.Controls.Add(this.labelDataCheckDistance);
            this.groupBoxSensorConfig.Location = new System.Drawing.Point(271, 313);
            this.groupBoxSensorConfig.Name = "groupBoxSensorConfig";
            this.groupBoxSensorConfig.Size = new System.Drawing.Size(284, 125);
            this.groupBoxSensorConfig.TabIndex = 4;
            this.groupBoxSensorConfig.TabStop = false;
            this.groupBoxSensorConfig.Text = "Sensor Configuration";
            // 
            // buttonTrkSave
            // 
            this.buttonTrkSave.Location = new System.Drawing.Point(36, 94);
            this.buttonTrkSave.Name = "buttonTrkSave";
            this.buttonTrkSave.Size = new System.Drawing.Size(75, 23);
            this.buttonTrkSave.TabIndex = 10;
            this.buttonTrkSave.Text = "Save";
            this.buttonTrkSave.UseVisualStyleBackColor = true;
            this.buttonTrkSave.Click += new System.EventHandler(this.buttonTrkSave_Click);
            // 
            // labelTrkUnloadRange
            // 
            this.labelTrkUnloadRange.AutoSize = true;
            this.labelTrkUnloadRange.Location = new System.Drawing.Point(158, 100);
            this.labelTrkUnloadRange.Name = "labelTrkUnloadRange";
            this.labelTrkUnloadRange.Size = new System.Drawing.Size(112, 13);
            this.labelTrkUnloadRange.TabIndex = 9;
            this.labelTrkUnloadRange.Text = "Unload Range: 0 - xxx";
            // 
            // numTrkUnloadDistance
            // 
            this.numTrkUnloadDistance.Location = new System.Drawing.Point(161, 72);
            this.numTrkUnloadDistance.Name = "numTrkUnloadDistance";
            this.numTrkUnloadDistance.Size = new System.Drawing.Size(120, 20);
            this.numTrkUnloadDistance.TabIndex = 8;
            // 
            // numTrkZoneStartDistance
            // 
            this.numTrkZoneStartDistance.Location = new System.Drawing.Point(161, 46);
            this.numTrkZoneStartDistance.Name = "numTrkZoneStartDistance";
            this.numTrkZoneStartDistance.Size = new System.Drawing.Size(120, 20);
            this.numTrkZoneStartDistance.TabIndex = 7;
            // 
            // numTrkDataCheckDistance
            // 
            this.numTrkDataCheckDistance.Location = new System.Drawing.Point(161, 20);
            this.numTrkDataCheckDistance.Name = "numTrkDataCheckDistance";
            this.numTrkDataCheckDistance.Size = new System.Drawing.Size(120, 20);
            this.numTrkDataCheckDistance.TabIndex = 6;
            // 
            // labelUnloadDistance
            // 
            this.labelUnloadDistance.AutoSize = true;
            this.labelUnloadDistance.Location = new System.Drawing.Point(33, 74);
            this.labelUnloadDistance.Name = "labelUnloadDistance";
            this.labelUnloadDistance.Size = new System.Drawing.Size(129, 13);
            this.labelUnloadDistance.TabIndex = 5;
            this.labelUnloadDistance.Text = "Data Unload Distance (m)";
            // 
            // labelZoneStartDistance
            // 
            this.labelZoneStartDistance.AutoSize = true;
            this.labelZoneStartDistance.Location = new System.Drawing.Point(33, 48);
            this.labelZoneStartDistance.Name = "labelZoneStartDistance";
            this.labelZoneStartDistance.Size = new System.Drawing.Size(119, 13);
            this.labelZoneStartDistance.TabIndex = 4;
            this.labelZoneStartDistance.Text = "Zone Start Distance (m)";
            // 
            // labelDataCheckDistance
            // 
            this.labelDataCheckDistance.AutoSize = true;
            this.labelDataCheckDistance.Location = new System.Drawing.Point(33, 22);
            this.labelDataCheckDistance.Name = "labelDataCheckDistance";
            this.labelDataCheckDistance.Size = new System.Drawing.Size(126, 13);
            this.labelDataCheckDistance.TabIndex = 3;
            this.labelDataCheckDistance.Text = "Data Check Distance (m)";
            // 
            // checkBoxCycle
            // 
            this.checkBoxCycle.AutoSize = true;
            this.checkBoxCycle.Location = new System.Drawing.Point(182, 413);
            this.checkBoxCycle.Name = "checkBoxCycle";
            this.checkBoxCycle.Size = new System.Drawing.Size(87, 17);
            this.checkBoxCycle.TabIndex = 2;
            this.checkBoxCycle.Text = "Cycle Bodies";
            this.checkBoxCycle.UseVisualStyleBackColor = true;
            this.checkBoxCycle.CheckedChanged += new System.EventHandler(this.checkBoxCycle_CheckedChanged);
            // 
            // buttonTrkStop
            // 
            this.buttonTrkStop.Enabled = false;
            this.buttonTrkStop.Location = new System.Drawing.Point(101, 410);
            this.buttonTrkStop.Name = "buttonTrkStop";
            this.buttonTrkStop.Size = new System.Drawing.Size(75, 23);
            this.buttonTrkStop.TabIndex = 1;
            this.buttonTrkStop.Text = "Stop";
            this.buttonTrkStop.UseVisualStyleBackColor = true;
            this.buttonTrkStop.Click += new System.EventHandler(this.buttonTrkStop_Click);
            // 
            // buttonTrkStart
            // 
            this.buttonTrkStart.Location = new System.Drawing.Point(20, 410);
            this.buttonTrkStart.Name = "buttonTrkStart";
            this.buttonTrkStart.Size = new System.Drawing.Size(75, 23);
            this.buttonTrkStart.TabIndex = 0;
            this.buttonTrkStart.Text = "Start";
            this.buttonTrkStart.UseVisualStyleBackColor = true;
            this.buttonTrkStart.Click += new System.EventHandler(this.buttonTrkStart_Click);
            // 
            // tabPageStopGo
            // 
            this.tabPageStopGo.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageStopGo.Location = new System.Drawing.Point(4, 22);
            this.tabPageStopGo.Name = "tabPageStopGo";
            this.tabPageStopGo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStopGo.Size = new System.Drawing.Size(567, 448);
            this.tabPageStopGo.TabIndex = 1;
            this.tabPageStopGo.Text = "Stop + Go";
            // 
            // tabPageConvConfig
            // 
            this.tabPageConvConfig.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageConvConfig.Controls.Add(this.groupBoxConvConfigAdd);
            this.tabPageConvConfig.Controls.Add(this.groupBoxPlcDbConfig);
            this.tabPageConvConfig.Location = new System.Drawing.Point(4, 22);
            this.tabPageConvConfig.Name = "tabPageConvConfig";
            this.tabPageConvConfig.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageConvConfig.Size = new System.Drawing.Size(567, 448);
            this.tabPageConvConfig.TabIndex = 2;
            this.tabPageConvConfig.Text = "Conv Config";
            // 
            // groupBoxConvConfigAdd
            // 
            this.groupBoxConvConfigAdd.Controls.Add(this.buttonConvConfigLoc);
            this.groupBoxConvConfigAdd.Controls.Add(this.textBoxConvConfigPath);
            this.groupBoxConvConfigAdd.Location = new System.Drawing.Point(214, 6);
            this.groupBoxConvConfigAdd.Name = "groupBoxConvConfigAdd";
            this.groupBoxConvConfigAdd.Size = new System.Drawing.Size(334, 86);
            this.groupBoxConvConfigAdd.TabIndex = 16;
            this.groupBoxConvConfigAdd.TabStop = false;
            this.groupBoxConvConfigAdd.Text = "Conveyor Configuration Path Location";
            // 
            // buttonConvConfigLoc
            // 
            this.buttonConvConfigLoc.Location = new System.Drawing.Point(286, 32);
            this.buttonConvConfigLoc.Name = "buttonConvConfigLoc";
            this.buttonConvConfigLoc.Size = new System.Drawing.Size(32, 23);
            this.buttonConvConfigLoc.TabIndex = 1;
            this.buttonConvConfigLoc.Text = "...";
            this.buttonConvConfigLoc.UseVisualStyleBackColor = true;
            // 
            // textBoxConvConfigPath
            // 
            this.textBoxConvConfigPath.Location = new System.Drawing.Point(17, 34);
            this.textBoxConvConfigPath.Name = "textBoxConvConfigPath";
            this.textBoxConvConfigPath.ReadOnly = true;
            this.textBoxConvConfigPath.Size = new System.Drawing.Size(263, 20);
            this.textBoxConvConfigPath.TabIndex = 0;
            // 
            // groupBoxPlcDbConfig
            // 
            this.groupBoxPlcDbConfig.Controls.Add(this.textBoxByteSize);
            this.groupBoxPlcDbConfig.Controls.Add(this.textBoxDbNo);
            this.groupBoxPlcDbConfig.Controls.Add(this.labelByteArraySize);
            this.groupBoxPlcDbConfig.Controls.Add(this.labelDataBlockNo);
            this.groupBoxPlcDbConfig.Location = new System.Drawing.Point(8, 6);
            this.groupBoxPlcDbConfig.Name = "groupBoxPlcDbConfig";
            this.groupBoxPlcDbConfig.Size = new System.Drawing.Size(200, 86);
            this.groupBoxPlcDbConfig.TabIndex = 0;
            this.groupBoxPlcDbConfig.TabStop = false;
            this.groupBoxPlcDbConfig.Text = "PLC DataBlock Configuration";
            // 
            // textBoxByteSize
            // 
            this.textBoxByteSize.Location = new System.Drawing.Point(111, 58);
            this.textBoxByteSize.Name = "textBoxByteSize";
            this.textBoxByteSize.Size = new System.Drawing.Size(83, 20);
            this.textBoxByteSize.TabIndex = 3;
            // 
            // textBoxDbNo
            // 
            this.textBoxDbNo.Location = new System.Drawing.Point(111, 31);
            this.textBoxDbNo.Name = "textBoxDbNo";
            this.textBoxDbNo.Size = new System.Drawing.Size(83, 20);
            this.textBoxDbNo.TabIndex = 2;
            // 
            // labelByteArraySize
            // 
            this.labelByteArraySize.AutoSize = true;
            this.labelByteArraySize.Location = new System.Drawing.Point(7, 61);
            this.labelByteArraySize.Name = "labelByteArraySize";
            this.labelByteArraySize.Size = new System.Drawing.Size(81, 13);
            this.labelByteArraySize.TabIndex = 1;
            this.labelByteArraySize.Text = "Byte Array Size ";
            // 
            // labelDataBlockNo
            // 
            this.labelDataBlockNo.AutoSize = true;
            this.labelDataBlockNo.Location = new System.Drawing.Point(7, 34);
            this.labelDataBlockNo.Name = "labelDataBlockNo";
            this.labelDataBlockNo.Size = new System.Drawing.Size(97, 13);
            this.labelDataBlockNo.TabIndex = 0;
            this.labelDataBlockNo.Text = "DataBlock Number";
            // 
            // tabPageNetConfig
            // 
            this.tabPageNetConfig.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageNetConfig.Controls.Add(this.groupBoxComms);
            this.tabPageNetConfig.Controls.Add(this.groupBoxIpAddPath);
            this.tabPageNetConfig.Controls.Add(this.groupBoxIpAdd);
            this.tabPageNetConfig.Controls.Add(this.labelTestText);
            this.tabPageNetConfig.Controls.Add(this.labelNetworkTestValue);
            this.tabPageNetConfig.Controls.Add(this.labelIPAddressTitle);
            this.tabPageNetConfig.Controls.Add(this.labelIPAddress);
            this.tabPageNetConfig.Controls.Add(this.shapeContainer2);
            this.tabPageNetConfig.Location = new System.Drawing.Point(4, 22);
            this.tabPageNetConfig.Name = "tabPageNetConfig";
            this.tabPageNetConfig.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageNetConfig.Size = new System.Drawing.Size(567, 448);
            this.tabPageNetConfig.TabIndex = 3;
            this.tabPageNetConfig.Text = "Network Config";
            // 
            // groupBoxComms
            // 
            this.groupBoxComms.Controls.Add(this.buttonNetworkConnect);
            this.groupBoxComms.Controls.Add(this.buttonNetworkDisconnect);
            this.groupBoxComms.Location = new System.Drawing.Point(23, 312);
            this.groupBoxComms.Name = "groupBoxComms";
            this.groupBoxComms.Size = new System.Drawing.Size(180, 100);
            this.groupBoxComms.TabIndex = 16;
            this.groupBoxComms.TabStop = false;
            this.groupBoxComms.Text = "PLC Communication";
            // 
            // buttonNetworkConnect
            // 
            this.buttonNetworkConnect.Location = new System.Drawing.Point(17, 22);
            this.buttonNetworkConnect.Name = "buttonNetworkConnect";
            this.buttonNetworkConnect.Size = new System.Drawing.Size(146, 26);
            this.buttonNetworkConnect.TabIndex = 0;
            this.buttonNetworkConnect.Text = "Connect";
            this.buttonNetworkConnect.UseVisualStyleBackColor = true;
            this.buttonNetworkConnect.Click += new System.EventHandler(this.buttonNetworkConnect_Click);
            // 
            // buttonNetworkDisconnect
            // 
            this.buttonNetworkDisconnect.Enabled = false;
            this.buttonNetworkDisconnect.Location = new System.Drawing.Point(17, 58);
            this.buttonNetworkDisconnect.Name = "buttonNetworkDisconnect";
            this.buttonNetworkDisconnect.Size = new System.Drawing.Size(146, 26);
            this.buttonNetworkDisconnect.TabIndex = 6;
            this.buttonNetworkDisconnect.Text = "Disconnect";
            this.buttonNetworkDisconnect.UseVisualStyleBackColor = true;
            this.buttonNetworkDisconnect.Click += new System.EventHandler(this.buttonNetworkDisconnect_Click);
            // 
            // groupBoxIpAddPath
            // 
            this.groupBoxIpAddPath.Controls.Add(this.buttonOpenPathLoc);
            this.groupBoxIpAddPath.Controls.Add(this.textBoxIpAddLoc);
            this.groupBoxIpAddPath.Location = new System.Drawing.Point(209, 12);
            this.groupBoxIpAddPath.Name = "groupBoxIpAddPath";
            this.groupBoxIpAddPath.Size = new System.Drawing.Size(334, 80);
            this.groupBoxIpAddPath.TabIndex = 15;
            this.groupBoxIpAddPath.TabStop = false;
            this.groupBoxIpAddPath.Text = "IP Address Path Location";
            // 
            // buttonOpenPathLoc
            // 
            this.buttonOpenPathLoc.Location = new System.Drawing.Point(286, 32);
            this.buttonOpenPathLoc.Name = "buttonOpenPathLoc";
            this.buttonOpenPathLoc.Size = new System.Drawing.Size(32, 23);
            this.buttonOpenPathLoc.TabIndex = 1;
            this.buttonOpenPathLoc.Text = "...";
            this.buttonOpenPathLoc.UseVisualStyleBackColor = true;
            this.buttonOpenPathLoc.Click += new System.EventHandler(this.buttonOpenPathLoc_Click);
            // 
            // textBoxIpAddLoc
            // 
            this.textBoxIpAddLoc.Location = new System.Drawing.Point(17, 34);
            this.textBoxIpAddLoc.Name = "textBoxIpAddLoc";
            this.textBoxIpAddLoc.ReadOnly = true;
            this.textBoxIpAddLoc.Size = new System.Drawing.Size(263, 20);
            this.textBoxIpAddLoc.TabIndex = 0;
            // 
            // groupBoxIpAdd
            // 
            this.groupBoxIpAdd.Controls.Add(this.buttonIpAddSave);
            this.groupBoxIpAdd.Controls.Add(this.ipAddressBox1);
            this.groupBoxIpAdd.Controls.Add(this.ipAddressBox4);
            this.groupBoxIpAdd.Controls.Add(this.ipAddressBox2);
            this.groupBoxIpAdd.Controls.Add(this.ipAddressBox3);
            this.groupBoxIpAdd.Location = new System.Drawing.Point(23, 12);
            this.groupBoxIpAdd.Name = "groupBoxIpAdd";
            this.groupBoxIpAdd.Size = new System.Drawing.Size(180, 80);
            this.groupBoxIpAdd.TabIndex = 14;
            this.groupBoxIpAdd.TabStop = false;
            this.groupBoxIpAdd.Text = "Edit IP Address";
            // 
            // buttonIpAddSave
            // 
            this.buttonIpAddSave.Location = new System.Drawing.Point(17, 52);
            this.buttonIpAddSave.Name = "buttonIpAddSave";
            this.buttonIpAddSave.Size = new System.Drawing.Size(146, 23);
            this.buttonIpAddSave.TabIndex = 14;
            this.buttonIpAddSave.Text = "Save";
            this.buttonIpAddSave.UseVisualStyleBackColor = true;
            this.buttonIpAddSave.Click += new System.EventHandler(this.buttonIpAddSave_Click);
            // 
            // ipAddressBox1
            // 
            this.ipAddressBox1.Location = new System.Drawing.Point(17, 25);
            this.ipAddressBox1.Name = "ipAddressBox1";
            this.ipAddressBox1.Size = new System.Drawing.Size(32, 20);
            this.ipAddressBox1.TabIndex = 10;
            // 
            // ipAddressBox4
            // 
            this.ipAddressBox4.Location = new System.Drawing.Point(131, 25);
            this.ipAddressBox4.Name = "ipAddressBox4";
            this.ipAddressBox4.Size = new System.Drawing.Size(32, 20);
            this.ipAddressBox4.TabIndex = 13;
            // 
            // ipAddressBox2
            // 
            this.ipAddressBox2.Location = new System.Drawing.Point(55, 25);
            this.ipAddressBox2.Name = "ipAddressBox2";
            this.ipAddressBox2.Size = new System.Drawing.Size(32, 20);
            this.ipAddressBox2.TabIndex = 11;
            // 
            // ipAddressBox3
            // 
            this.ipAddressBox3.Location = new System.Drawing.Point(93, 25);
            this.ipAddressBox3.Name = "ipAddressBox3";
            this.ipAddressBox3.Size = new System.Drawing.Size(32, 20);
            this.ipAddressBox3.TabIndex = 12;
            // 
            // labelTestText
            // 
            this.labelTestText.AutoSize = true;
            this.labelTestText.Location = new System.Drawing.Point(442, 427);
            this.labelTestText.Name = "labelTestText";
            this.labelTestText.Size = new System.Drawing.Size(58, 13);
            this.labelTestText.TabIndex = 4;
            this.labelTestText.Text = "Test Value";
            // 
            // labelNetworkTestValue
            // 
            this.labelNetworkTestValue.AutoSize = true;
            this.labelNetworkTestValue.Location = new System.Drawing.Point(508, 427);
            this.labelNetworkTestValue.Name = "labelNetworkTestValue";
            this.labelNetworkTestValue.Size = new System.Drawing.Size(35, 13);
            this.labelNetworkTestValue.TabIndex = 3;
            this.labelNetworkTestValue.Text = "XXXX";
            // 
            // labelIPAddressTitle
            // 
            this.labelIPAddressTitle.AutoSize = true;
            this.labelIPAddressTitle.Location = new System.Drawing.Point(8, 427);
            this.labelIPAddressTitle.Name = "labelIPAddressTitle";
            this.labelIPAddressTitle.Size = new System.Drawing.Size(58, 13);
            this.labelIPAddressTitle.TabIndex = 2;
            this.labelIPAddressTitle.Text = "IP Address";
            // 
            // labelIPAddress
            // 
            this.labelIPAddress.AutoSize = true;
            this.labelIPAddress.Location = new System.Drawing.Point(75, 427);
            this.labelIPAddress.Name = "labelIPAddress";
            this.labelIPAddress.Size = new System.Drawing.Size(40, 13);
            this.labelIPAddress.TabIndex = 1;
            this.labelIPAddress.Text = "0.0.0.0";
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.rectangleShape1});
            this.shapeContainer2.Size = new System.Drawing.Size(561, 442);
            this.shapeContainer2.TabIndex = 17;
            this.shapeContainer2.TabStop = false;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.Location = new System.Drawing.Point(-2, 415);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(565, 29);
            // 
            // tabPageLog
            // 
            this.tabPageLog.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageLog.Controls.Add(this.listBoxLog);
            this.tabPageLog.Location = new System.Drawing.Point(4, 22);
            this.tabPageLog.Name = "tabPageLog";
            this.tabPageLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLog.Size = new System.Drawing.Size(567, 448);
            this.tabPageLog.TabIndex = 4;
            this.tabPageLog.Text = "Log";
            // 
            // listBoxLog
            // 
            this.listBoxLog.FormattingEnabled = true;
            this.listBoxLog.Location = new System.Drawing.Point(6, 5);
            this.listBoxLog.Name = "listBoxLog";
            this.listBoxLog.Size = new System.Drawing.Size(555, 433);
            this.listBoxLog.TabIndex = 0;
            // 
            // tabPageAbout
            // 
            this.tabPageAbout.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageAbout.Controls.Add(this.labelAboutVersion);
            this.tabPageAbout.Controls.Add(this.labelAboutProgramTitle);
            this.tabPageAbout.Controls.Add(this.labelAboutTitle);
            this.tabPageAbout.Controls.Add(this.shapeContainer1);
            this.tabPageAbout.Location = new System.Drawing.Point(4, 22);
            this.tabPageAbout.Name = "tabPageAbout";
            this.tabPageAbout.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAbout.Size = new System.Drawing.Size(567, 448);
            this.tabPageAbout.TabIndex = 5;
            this.tabPageAbout.Text = "About";
            // 
            // labelAboutVersion
            // 
            this.labelAboutVersion.AutoSize = true;
            this.labelAboutVersion.Location = new System.Drawing.Point(25, 95);
            this.labelAboutVersion.Name = "labelAboutVersion";
            this.labelAboutVersion.Size = new System.Drawing.Size(100, 13);
            this.labelAboutVersion.TabIndex = 2;
            this.labelAboutVersion.Text = "Version 1.0.0 BETA";
            // 
            // labelAboutProgramTitle
            // 
            this.labelAboutProgramTitle.AutoSize = true;
            this.labelAboutProgramTitle.Location = new System.Drawing.Point(25, 78);
            this.labelAboutProgramTitle.Name = "labelAboutProgramTitle";
            this.labelAboutProgramTitle.Size = new System.Drawing.Size(98, 13);
            this.labelAboutProgramTitle.TabIndex = 1;
            this.labelAboutProgramTitle.Text = "Conveyor Simulator";
            // 
            // labelAboutTitle
            // 
            this.labelAboutTitle.AutoSize = true;
            this.labelAboutTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.labelAboutTitle.Location = new System.Drawing.Point(25, 7);
            this.labelAboutTitle.Name = "labelAboutTitle";
            this.labelAboutTitle.Size = new System.Drawing.Size(196, 17);
            this.labelAboutTitle.TabIndex = 0;
            this.labelAboutTitle.Text = "About Conveyor Simulator";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.rectangleAboutLogo});
            this.shapeContainer1.Size = new System.Drawing.Size(561, 442);
            this.shapeContainer1.TabIndex = 3;
            this.shapeContainer1.TabStop = false;
            // 
            // rectangleAboutLogo
            // 
            this.rectangleAboutLogo.Location = new System.Drawing.Point(23, 26);
            this.rectangleAboutLogo.Name = "rectangleAboutLogo";
            this.rectangleAboutLogo.Size = new System.Drawing.Size(105, 39);
            // 
            // timerNetworkScan
            // 
            this.timerNetworkScan.Interval = 300;
            this.timerNetworkScan.Tick += new System.EventHandler(this.timerNetworkScan_Tick);
            // 
            // timerEventLog
            // 
            this.timerEventLog.Enabled = true;
            this.timerEventLog.Tick += new System.EventHandler(this.timerEventLog_Tick);
            // 
            // openFileDialogIpAdd
            // 
            this.openFileDialogIpAdd.FileName = "Proxy.txt";
            this.openFileDialogIpAdd.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialogIpAdd_FileOk);
            // 
            // timerMoving
            // 
            this.timerMoving.Interval = 1000;
            this.timerMoving.Tick += new System.EventHandler(this.timerMoving_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 475);
            this.Controls.Add(this.tabControlConveyorSim);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Conveyor Simulator Version 1.0.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControlConveyorSim.ResumeLayout(false);
            this.tabPageTracking.ResumeLayout(false);
            this.tabPageTracking.PerformLayout();
            this.groupBoxTrkConfig.ResumeLayout(false);
            this.groupBoxTrkConfig.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkDistance)).EndInit();
            this.groupBoxSensorConfig.ResumeLayout(false);
            this.groupBoxSensorConfig.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkUnloadDistance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkZoneStartDistance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTrkDataCheckDistance)).EndInit();
            this.tabPageConvConfig.ResumeLayout(false);
            this.groupBoxConvConfigAdd.ResumeLayout(false);
            this.groupBoxConvConfigAdd.PerformLayout();
            this.groupBoxPlcDbConfig.ResumeLayout(false);
            this.groupBoxPlcDbConfig.PerformLayout();
            this.tabPageNetConfig.ResumeLayout(false);
            this.tabPageNetConfig.PerformLayout();
            this.groupBoxComms.ResumeLayout(false);
            this.groupBoxIpAddPath.ResumeLayout(false);
            this.groupBoxIpAddPath.PerformLayout();
            this.groupBoxIpAdd.ResumeLayout(false);
            this.groupBoxIpAdd.PerformLayout();
            this.tabPageLog.ResumeLayout(false);
            this.tabPageAbout.ResumeLayout(false);
            this.tabPageAbout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlConveyorSim;
        private System.Windows.Forms.TabPage tabPageTracking;
        private System.Windows.Forms.TabPage tabPageStopGo;
        private System.Windows.Forms.TabPage tabPageConvConfig;
        private System.Windows.Forms.TabPage tabPageNetConfig;
        private System.Windows.Forms.TabPage tabPageLog;
        private System.Windows.Forms.TabPage tabPageAbout;
        private System.Windows.Forms.Label labelAboutVersion;
        private System.Windows.Forms.Label labelAboutProgramTitle;
        private System.Windows.Forms.Label labelAboutTitle;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleAboutLogo;
        private System.Windows.Forms.Label labelTestText;
        private System.Windows.Forms.Label labelNetworkTestValue;
        private System.Windows.Forms.Label labelIPAddressTitle;
        private System.Windows.Forms.Label labelIPAddress;
        private System.Windows.Forms.Button buttonNetworkConnect;
        private System.Windows.Forms.Timer timerNetworkScan;
        private System.Windows.Forms.ListBox listBoxLog;
        private System.Windows.Forms.Button buttonNetworkDisconnect;
        private System.Windows.Forms.Timer timerEventLog;
        private System.Windows.Forms.TextBox ipAddressBox4;
        private System.Windows.Forms.TextBox ipAddressBox3;
        private System.Windows.Forms.TextBox ipAddressBox2;
        private System.Windows.Forms.TextBox ipAddressBox1;
        private System.Windows.Forms.GroupBox groupBoxIpAdd;
        private System.Windows.Forms.Button buttonIpAddSave;
        private System.Windows.Forms.OpenFileDialog openFileDialogIpAdd;
        private System.Windows.Forms.GroupBox groupBoxIpAddPath;
        private System.Windows.Forms.Button buttonOpenPathLoc;
        private System.Windows.Forms.TextBox textBoxIpAddLoc;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogIpAdd;
        private System.Windows.Forms.GroupBox groupBoxComms;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private System.Windows.Forms.GroupBox groupBoxConvConfigAdd;
        private System.Windows.Forms.Button buttonConvConfigLoc;
        private System.Windows.Forms.TextBox textBoxConvConfigPath;
        private System.Windows.Forms.GroupBox groupBoxPlcDbConfig;
        private System.Windows.Forms.TextBox textBoxByteSize;
        private System.Windows.Forms.TextBox textBoxDbNo;
        private System.Windows.Forms.Label labelByteArraySize;
        private System.Windows.Forms.Label labelDataBlockNo;
        private System.Windows.Forms.Timer timerMoving;
        private System.Windows.Forms.Button buttonTrkStop;
        private System.Windows.Forms.Button buttonTrkStart;
        private System.Windows.Forms.CheckBox checkBoxCycle;
        private System.Windows.Forms.GroupBox groupBoxSensorConfig;
        private System.Windows.Forms.Label labelUnloadDistance;
        private System.Windows.Forms.Label labelZoneStartDistance;
        private System.Windows.Forms.Label labelDataCheckDistance;
        private System.Windows.Forms.NumericUpDown numTrkUnloadDistance;
        private System.Windows.Forms.NumericUpDown numTrkZoneStartDistance;
        private System.Windows.Forms.NumericUpDown numTrkDataCheckDistance;
        private System.Windows.Forms.Label labelTrkUnloadRange;
        private System.Windows.Forms.GroupBox groupBoxTrkConfig;
        private System.Windows.Forms.Button buttonTrkSave;
        private System.Windows.Forms.NumericUpDown numTrkSpeed;
        private System.Windows.Forms.NumericUpDown numTrkDistance;
        private System.Windows.Forms.Label labelTrackSpeed;
        private System.Windows.Forms.Label labelTrkDistance;
    }
}

