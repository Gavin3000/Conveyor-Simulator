﻿using System;
using System.Linq;

namespace Conveyor_Simulation_Version_1_0_0
{
    class TrackingManager
    {
        //Constant Variables

        //Local Variables
        private bool bodyQueueFinished, bodyStartSequence;
        private int[] bodyPos, _x, _y;
        //Global Variables
        public int BodyQueueSize;
        public Body[] BodyData;
        //Class Declarations
        EventLogger globalEventLogger = new EventLogger();
        //Constructor Initialisation
        public TrackingManager(int StartBodyPos_x, int StartBodyPos_y)
        {
            _x = new int[BodyQueueSize];
            _y = new int[BodyQueueSize];
            bodyPos = new int[BodyQueueSize];
            for (int i = 0; i < BodyQueueSize; i++)
            {
                _x[i] = StartBodyPos_x;
                _y[i] = StartBodyPos_y;
                BodyData[i] = new Body(_x[i],_y[i]);
            }
        }

        public void LineManager()
        {
            if (BodyData[0].BodyStart || bodyStartSequence)
            {
                bool first = true;
                for (int i = 0; i < BodyQueueSize; i++)
                {
                    //Bit of a trick, missed reading the first array location within this if else statement
                    if (first)
                    {
                        first = false;
                        bodyStartSequence = true;
                    }
                    else if ((BodyData[i-1].CurrentBodyPos_x >= BodyData[i-1].Gapping) && (BodyData[i].CurrentBodyPos_x < BodyData[i].TrackLength_Width) && !first)
                    {
                        BodyData[i].BodyStart = true;
                        BodyData[i].BodyStop = false;
                    }

                    //Testing Logging
                    //globalEventLogger.eventLogList("1000", "Tracking Manager", string.Format("BodyID:{1}, Current Pos_x: {0}", BodyData[i].BodyStart, BodyData[i].intBodyID));
                    //globalEventLogger.eventLogList("1000", "Tracking Manager", string.Format("BodyID:{1}, Current Pos_x: {0}",BodyData[9].CurrentBodyPos_x,BodyData[9].intBodyID));
                }
            }

            for (int i = 0; i < BodyQueueSize; i++)
            {
                if ((BodyData[i].CurrentBodyPos_x >= BodyData[i].TrackLength_Width) && BodyData[i].BodyStart)
                {
                    BodyData[i].BodyStart = false;
                    BodyData[i].BodyStop = true;
                }                   
            }

            //Linq check for All BodyStart signals
            bodyQueueFinished = BodyData.All(body => body.BodyStart == false);
            if (bodyQueueFinished)
            {
                bodyStartSequence = false;
            }
            //Start first body again if Cycling Option selected and Last Body has finished or is greater than its gapping distance.
            if (BodyData[0].RecyclePos && (bodyQueueFinished || (BodyData[BodyQueueSize-1].CurrentBodyPos_x >= BodyData[BodyQueueSize-1].Gapping)))
            {
                BodyData[0].BodyStart = true;
                BodyData[0].BodyStop = false;          
            }
        }
    }
}
