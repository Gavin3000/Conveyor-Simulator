﻿using System;

namespace Conveyor_Simulation_Version_1_0_0
{
    class EventLogger
    {
        public void eventLogList(string eventID, string eventLocation, string eventDescription)
        {
            Globals.form.addEventLogger(DateTime.Now + " :  EventID: " + eventID + " :  EventLoc: " + eventLocation + " :  " + eventDescription);
        }

        public void eventLogText()
        {
            //Future Development -- Make a Text File Logger
        }

    }
}
